package filetypes;

%filetypes=
(
);

1;
